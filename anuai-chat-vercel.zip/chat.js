
async function sendMessage() {
  const input = document.getElementById("input");
  const chatbox = document.getElementById("chatbox");
  const userMsg = input.value;
  if (!userMsg.trim()) return;

  chatbox.innerHTML += `<div><b>Anda:</b> ${userMsg}</div>`;
  input.value = "";
  chatbox.scrollTop = chatbox.scrollHeight;

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: userMsg })
    });
    const data = await res.json();
    chatbox.innerHTML += `<div><b>AnuAI:</b> ${data.reply}</div>`;
    chatbox.scrollTop = chatbox.scrollHeight;
  } catch (err) {
    chatbox.innerHTML += `<div><i>Ralat sambungan ke AI.</i></div>`;
  }
}
